# lab09_features_stacking_lime.py
# Works with features.npy (X: [n_samples, n_features]) and labels.npy (y: [n_samples])
# A1: Stacking (Classifier/Regressor)
# A2: Pipeline (Imputer->Scaler->Model)
# A3: LIME (tabular) explanations saved as HTML
#
# Requirements:
#   pip install numpy pandas scikit-learn lime

from __future__ import annotations
import os
import warnings
from dataclasses import dataclass
from typing import List, Optional, Dict, Any

import numpy as np
import pandas as pd

from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.metrics import (
    accuracy_score, f1_score, roc_auc_score, classification_report,
    mean_absolute_error, mean_squared_error, r2_score
)
from sklearn.linear_model import LogisticRegression, RidgeCV, LinearRegression
from sklearn.ensemble import (
    RandomForestClassifier, RandomForestRegressor,
    StackingClassifier, StackingRegressor
)
from sklearn.neighbors import KNeighborsClassifier, KNeighborsRegressor
from sklearn.svm import SVC, SVR

from lime.lime_tabular import LimeTabularExplainer

warnings.filterwarnings("ignore")

FEATURES_NPY_PATH = "features_fast.npy"   # X: shape (n_samples, n_features)
LABELS_NPY_PATH   = "labels_fast.npy"     # y: shape (n_samples,)
TASK_TYPE = "classification"         # "classification" or "regression"
TEST_SIZE = 0.2
RANDOM_SEED = 42
N_EXPLANATIONS = 5                   # LIME explanations to generate from test set
OUTPUT_DIR = "lime_html"             # folder to save HTML files



@dataclass
class Dataset:
    X_train: np.ndarray
    X_test: np.ndarray
    y_train: np.ndarray
    y_test: np.ndarray
    feature_names: List[str]
    class_names: Optional[List[str]] = None


#DATA LOADING 

def _ensure_2d(X: np.ndarray) -> np.ndarray:
    X = np.asarray(X)
    if X.ndim == 1:
        X = X.reshape(-1, 1)
    return X

def load_data(features_path: str, labels_path: str, task_type: str) -> Dataset:
    X = np.load(features_path)
    y = np.load(labels_path)

    X = _ensure_2d(X)
    if X.shape[0] != len(y):
        raise ValueError(f"Row mismatch: X has {X.shape[0]} rows but y has {len(y)}.")

    feature_names = [f"f{i}" for i in range(X.shape[1])]
    class_names = None
    if task_type == "classification":
        uniq = np.unique(y)
        class_names = [str(c) for c in sorted(uniq.tolist())]

    stratify = y if (task_type == "classification" and len(np.unique(y)) > 1) else None
    X_tr, X_te, y_tr, y_te = train_test_split(
        X, y, test_size=TEST_SIZE, random_state=RANDOM_SEED, stratify=stratify
    )
    return Dataset(X_tr, X_te, y_tr, y_te, feature_names, class_names)


# MODEL / PIPELINE BUILD 

def get_classification_base_estimators():
    return [
        ("logreg", LogisticRegression(max_iter=2000)),
        ("rf", RandomForestClassifier(n_estimators=300, random_state=RANDOM_SEED)),
        ("svc", SVC(kernel="rbf", probability=True, random_state=RANDOM_SEED)),
        ("knn", KNeighborsClassifier(n_neighbors=7)),
    ]

def get_regression_base_estimators():
    return [
        ("lin", LinearRegression()),
        ("rf", RandomForestRegressor(n_estimators=400, random_state=RANDOM_SEED)),
        ("svr", SVR()),
        ("knn", KNeighborsRegressor(n_neighbors=7)),
    ]

def build_stacking(task_type: str):
    if task_type == "classification":
        base = get_classification_base_estimators()
        final = LogisticRegression(max_iter=3000)
        return StackingClassifier(estimators=base, final_estimator=final, passthrough=False, stack_method="auto")
    elif task_type == "regression":
        base = get_regression_base_estimators()
        final = RidgeCV(alphas=(0.1, 1.0, 10.0))
        return StackingRegressor(estimators=base, final_estimator=final, passthrough=False)
    else:
        raise ValueError("TASK_TYPE must be 'classification' or 'regression'")

def build_pipeline(task_type: str) -> Pipeline:
    preprocess = Pipeline(steps=[
        ("imputer", SimpleImputer(strategy="median")),
        ("scaler", StandardScaler())
    ])
    model = build_stacking(task_type)
    pipe = Pipeline(steps=[
        ("prep", preprocess),
        ("model", model)
    ])
    return pipe


#  EVALUATION 

def evaluate_classification(pipe: Pipeline, X_test: np.ndarray, y_test: np.ndarray) -> Dict[str, Any]:
    y_pred = pipe.predict(X_test)
    out = {
        "accuracy": float(accuracy_score(y_test, y_pred)),
        "f1_macro": float(f1_score(y_test, y_pred, average="macro")),
        "report": classification_report(y_test, y_pred, zero_division=0)
    }
    try:
        y_prob = pipe.predict_proba(X_test)
        if y_prob.shape[1] == 2:
            out["roc_auc"] = float(roc_auc_score(y_test, y_prob[:, 1]))
        else:
            out["roc_auc_ovo_weighted"] = float(
                roc_auc_score(y_test, y_prob, multi_class="ovo", average="weighted")
            )
    except Exception:
        pass
    return out

def evaluate_regression(pipe: Pipeline, X_test: np.ndarray, y_test: np.ndarray) -> Dict[str, float]:
    y_pred = pipe.predict(X_test)
    mae = float(mean_absolute_error(y_test, y_pred))
    rmse = float(np.sqrt(mean_squared_error(y_test, y_pred)))
    r2 = float(r2_score(y_test, y_pred))
    return {"MAE": mae, "RMSE": rmse, "R2": r2}


# LIME 
def prepare_lime_explainer(pipe: Pipeline, X_train: np.ndarray, feature_names: List[str],
                           task_type: str, class_names: Optional[List[str]]):
    # Fit only the preprocessing so LIME uses the right distribution
    pipe.fit(X_train, np.zeros(len(X_train)))  # y not needed for transform
    X_train_trans = pipe.named_steps["prep"].transform(X_train)

    if task_type == "classification":
        explainer = LimeTabularExplainer(
            training_data=np.array(X_train_trans),
            feature_names=feature_names,
            class_names=class_names,
            mode="classification",
            discretize_continuous=True
        )
    else:
        explainer = LimeTabularExplainer(
            training_data=np.array(X_train_trans),
            feature_names=feature_names,
            mode="regression",
            discretize_continuous=True
        )
    return explainer

def lime_predict_fn_factory(pipe: Pipeline, task_type: str):
    prep = pipe.named_steps["prep"]
    model = pipe.named_steps["model"]

    def predict_fn_classification(X_raw: np.ndarray) -> np.ndarray:
        Z = prep.transform(X_raw)
        if hasattr(model, "predict_proba"):
            return model.predict_proba(Z)
        # fallback via decision_function -> softmax / logistic
        if hasattr(model, "decision_function"):
            scores = model.decision_function(Z)
            if scores.ndim == 1:
                p1 = 1 / (1 + np.exp(-scores))
                return np.vstack([1 - p1, p1]).T
            e = np.exp(scores - scores.max(axis=1, keepdims=True))
            return e / e.sum(axis=1, keepdims=True)
        preds = model.predict(Z)
        classes = np.unique(preds)
        out = np.zeros((len(preds), len(classes)))
        for i, c in enumerate(classes):
            out[:, i] = (preds == c).astype(float)
        return out

    def predict_fn_regression(X_raw: np.ndarray) -> np.ndarray:
        Z = prep.transform(X_raw)
        preds = model.predict(Z)
        return preds.reshape(-1, 1)

    return predict_fn_classification if task_type == "classification" else predict_fn_regression

def generate_lime_html(explainer: LimeTabularExplainer, pipe: Pipeline,
                       X_test: np.ndarray, feature_names: List[str],
                       task_type: str, n_explanations: int, output_dir: str) -> None:
    os.makedirs(output_dir, exist_ok=True)
    predict_fn = lime_predict_fn_factory(pipe, task_type)
    # explain first n_explanations rows
    k = min(n_explanations, len(X_test))
    for i in range(k):
        exp = explainer.explain_instance(
            data_row=X_test[i],
            predict_fn=predict_fn,
            num_features=min(10, len(feature_names))
        )
        out_path = os.path.join(output_dir, f"lime_sample_{i}.html")
        exp.save_to_file(out_path)


# MAIN 

def main():
    # Load
    data = load_data(FEATURES_NPY_PATH, LABELS_NPY_PATH, TASK_TYPE)

    # Build pipeline
    pipe = build_pipeline(TASK_TYPE)

    # Train (full pipeline)
    pipe.fit(data.X_train, data.y_train)

    # Evaluate
    if TASK_TYPE == "classification":
        metrics = evaluate_classification(pipe, data.X_test, data.y_test)
        print("=== Classification Metrics ===")
        print(f"Accuracy : {metrics['accuracy']:.4f}")
        print(f"F1-macro: {metrics['f1_macro']:.4f}")
        if "roc_auc" in metrics:
            print(f"ROC-AUC : {metrics['roc_auc']:.4f}")
        if "roc_auc_ovo_weighted" in metrics:
            print(f"ROC-AUC (OVO, weighted): {metrics['roc_auc_ovo_weighted']:.4f}")
        print("\nClassification Report:\n", metrics["report"])
    else:
        metrics = evaluate_regression(pipe, data.X_test, data.y_test)
        print("=== Regression Metrics ===")
        print(f"MAE : {metrics['MAE']:.4f}")
        print(f"RMSE: {metrics['RMSE']:.4f}")
        print(f"R^2 : {metrics['R2']:.4f}")

    # LIME explanations
    explainer = prepare_lime_explainer(pipe, data.X_train, data.feature_names, TASK_TYPE, data.class_names)
    generate_lime_html(explainer, pipe, data.X_test, data.feature_names, TASK_TYPE, N_EXPLANATIONS, OUTPUT_DIR)
    print(f"\nSaved {min(N_EXPLANATIONS, len(data.X_test))} LIME explanations to: {OUTPUT_DIR}/")


if __name__ == "__main__":
    main()
